# Bootstrap-Assignment-1
This assignment covers the introduction to the Bootstrap framework, the Bootstrap grid, and Navigation items
